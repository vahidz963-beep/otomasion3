/* Aryaman Calculator Report — vanilla port of the automation print base 136.0.1
   (customer datasheet + board one-sheet). No dependencies, PHP 7.4-safe. */
(() => {
  'use strict';
const TransformerDiagram = (() => {
  'use strict';
  var G = {
    pinSpacing: 58, minInterior: 160, coreTop: 100, coreLeft: 45, coreWidth: 350, coreRadius: 18,
    labelMargin: 100, pinInset: 34, coilOffset: 55, nestStep: 27.5, loopStep: 15, bulge: 13,
    titleGap: 30, legendRow: 22, outsideOffset: 40, gridStep: 3, pad: 3
  };
  var COLOR = { ink: '#16325c', paper: '#fbfaf6', wire: '#1e3a8a', accent: '#c1440e', muted: '#7f9cd6' };
  var LIMITS = { maxPinsPerSide: 30, maxWindings: 12 };
  var FONT = "'Aryaman Vazirmatn', Vazirmatn, Tahoma, Arial, sans-serif";

  function f(n) { return (Math.round(n * 100) / 100).toString(); }

  function parsePins(str) {
    var m = /^\s*(\d+)\s*\+\s*(\d+)\s*$/.exec(String(str || ''));
    return m ? { left: parseInt(m[1], 10), right: parseInt(m[2], 10) } : null;
  }
  function validatePins(left, right) {
    var errs = [];
    if (!Number.isInteger(left) || left < 1 || left > LIMITS.maxPinsPerSide) errs.push('تعداد پایه‌های سمت چپ باید بین ۱ و ' + LIMITS.maxPinsPerSide + ' باشد.');
    if (!Number.isInteger(right) || right < 1 || right > LIMITS.maxPinsPerSide) errs.push('تعداد پایه‌های سمت راست باید بین ۱ و ' + LIMITS.maxPinsPerSide + ' باشد.');
    return errs;
  }
  function pinSide(num, left) { return num <= left ? 'left' : 'right'; }

  function validateWindings(windings, left, right, allowCrossSide) {
    var total = left + right, valid = [], errors = [];
    if (windings.length > LIMITS.maxWindings) errors.push({ message: 'حداکثر ' + LIMITS.maxWindings + ' سیم‌پیچ مجاز است.' });
    windings.forEach(function (w, i) {
      var idx = i + 1, msgs = [];
      var s = w.start, e = w.end;
      if (!Number.isInteger(s) || !Number.isInteger(e)) msgs.push('پایه شروع و پایان را انتخاب کنید.');
      else if (s < 1 || s > total || e < 1 || e > total) msgs.push('پایه‌ها باید بین ۱ و ' + total + ' باشند.');
      else if (s === e) msgs.push('پایه شروع و پایان نباید یکی باشند.');
      else if (!allowCrossSide && pinSide(s, left) !== pinSide(e, left)) msgs.push('شروع و پایان باید در یک سمت باشند (سیم‌پیچ دوسمتی غیرفعال است).');
      var t = Number(w.turns || 0);
      if (!Number.isInteger(t) || t < 0) msgs.push('تعداد دور باید عدد صحیح و غیرمنفی باشد.');
      if (msgs.length) errors.push({ index: idx, message: 'سیم‌پیچ ' + idx + ': ' + msgs.join(' ') });
      else valid.push({
        index: idx, name: w.name || ('Winding ' + idx), start: s, end: e, turns: t,
        wire: String(w.wire || '0.25').trim(),
        strand: Math.max(1, parseInt(w.strand, 10) || 1),
        layer: Math.max(1, parseInt(w.layer, 10) || 1),
        direction: String(w.direction || 'CW'),
        insulation: String(w.insulation || '3').trim()
      });
    });
    return { valid: valid, errors: errors };
  }

  function pathOp(d, o) { return { t: 'path', d: d, stroke: o.stroke || null, fill: o.fill || null, width: o.width || 1, cap: o.cap || 'butt', dash: o.dash || null }; }
  function circleOp(x, y, r, o) { return { t: 'circle', x: x, y: y, r: r, fill: o.fill || null, stroke: o.stroke || null, width: o.width || 1 }; }
  function textOp(x, y, s, o) { return { t: 'text', x: x, y: y, s: String(s), size: o.size || 15, weight: o.weight || 400, color: o.color || COLOR.ink, align: o.align || 'start', halo: o.halo !== false }; }

  function roundRectD(x, y, w, h, r) {
    return 'M ' + f(x + r) + ' ' + f(y) + ' L ' + f(x + w - r) + ' ' + f(y) +
      ' A ' + r + ' ' + r + ' 0 0 1 ' + f(x + w) + ' ' + f(y + r) + ' L ' + f(x + w) + ' ' + f(y + h - r) +
      ' A ' + r + ' ' + r + ' 0 0 1 ' + f(x + w - r) + ' ' + f(y + h) + ' L ' + f(x + r) + ' ' + f(y + h) +
      ' A ' + r + ' ' + r + ' 0 0 1 ' + f(x) + ' ' + f(y + h - r) + ' L ' + f(x) + ' ' + f(y + r) +
      ' A ' + r + ' ' + r + ' 0 0 1 ' + f(x + r) + ' ' + f(y) + ' Z';
  }

  // کویل عمودی کنار ستون پایه‌ها
  function coilVertical(x, yTop, yBottom, dir) {
    var span = Math.max(24, yBottom - yTop), loops = Math.max(2, Math.round(span / G.loopStep)), step = span / loops, b = G.bulge * dir;
    var d = 'M ' + f(x) + ' ' + f(yTop);
    for (var i = 0; i < loops; i++) {
      var s = yTop + i * step, e = yTop + (i + 1) * step;
      d += ' C ' + f(x + b) + ' ' + f(s + step * 0.28) + ' ' + f(x + b) + ' ' + f(s + step * 0.72) + ' ' + f(x) + ' ' + f(e);
    }
    return { d: d };
  }
  // کویل افقی داخل پنجره (مدل A)
  function coilHorizontal(xL, xR, y, dirY) {
    var span = Math.max(24, xR - xL), loops = Math.max(2, Math.round(span / G.loopStep)), step = span / loops, b = G.bulge * dirY;
    var d = 'M ' + f(xL) + ' ' + f(y);
    for (var i = 0; i < loops; i++) {
      var s = xL + i * step, e = xL + (i + 1) * step;
      d += ' C ' + f(s + step * 0.28) + ' ' + f(y + b) + ' ' + f(s + step * 0.72) + ' ' + f(y + b) + ' ' + f(e) + ' ' + f(y);
    }
    return { d: d };
  }

  // ---- مستطیل‌های برخورد (موانع) ----
  function rect(x1, y1, x2, y2) { return { x1: Math.min(x1, x2), y1: Math.min(y1, y2), x2: Math.max(x1, x2), y2: Math.max(y1, y2) }; }
  function hit(a, b, pad) { pad = pad || 0; return a.x1 - pad < b.x2 && b.x1 - pad < a.x2 && a.y1 - pad < b.y2 && b.y1 - pad < a.y2; }

  // برچسب یک‌خطی با رنگ مشخص (N قرمز، تعداد دور مشکی)
  function labelVariant(cx, cy, text, color) {
    var w = text.length * 8.4 + 6;
    return { rect: rect(cx - w / 2, cy - 10, cx + w / 2, cy + 4), ops: [textOp(cx, cy + 4, text, { size: 13, weight: 700, color: color, align: 'middle' })] };
  }

  function buildScene(config) {
    var left = config.left, right = config.right, total = left + right;
    var pinErrs = validatePins(left, right);
    if (pinErrs.length) return { width: 0, height: 0, ops: [], errors: pinErrs.map(function (m) { return { message: m }; }), windings: [], pins: {} };

    var allowCross = !!config.allowCrossSide;
    var wRes = validateWindings(config.windings || [], left, right, allowCross);
    var windings = wRes.valid;

    var leftH = left > 1 ? G.pinSpacing * (left - 1) : G.pinSpacing * 0.6;
    var rightH = right > 1 ? G.pinSpacing * (right - 1) : G.pinSpacing * 0.6;
    var interior = Math.max(leftH, rightH, G.minInterior);
    var coreTop = G.coreTop, coreBottom = coreTop + interior + 60;
    var coreLeft = G.coreLeft + G.labelMargin, coreRight = coreLeft + G.coreWidth, midX = (coreLeft + coreRight) / 2;

    var legendBase = coreBottom + 66;
    var height = coreBottom + 70;
    var width = coreRight + G.labelMargin;

    var ops = [];
    var view = config.title || 'نمای بالا';
    ops.push(textOp(midX, coreTop - G.titleGap, view, { size: 22, weight: 600, align: 'middle' }));
    ops.push(pathOp(roundRectD(coreLeft, coreTop, G.coreWidth, coreBottom - coreTop, G.coreRadius), { stroke: COLOR.ink, width: 2.5 }));
    ops.push(pathOp('M ' + f(midX - 6) + ' ' + f(coreTop + 16) + ' L ' + f(midX - 6) + ' ' + f(coreBottom - 16), { stroke: COLOR.ink, width: 2 }));
    ops.push(pathOp('M ' + f(midX + 6) + ' ' + f(coreTop + 16) + ' L ' + f(midX + 6) + ' ' + f(coreBottom - 16), { stroke: COLOR.ink, width: 2 }));

    var obstacles = [
      rect(midX - 8, coreTop + 12, midX + 8, coreBottom - 12) // میله‌های عایق
    ];

    var leftStartY = coreTop + 30 + (interior - leftH) / 2, rightStartY = coreTop + 30 + (interior - rightH) / 2;
    var leftPinX = coreLeft + G.pinInset, rightPinX = coreRight - G.pinInset;
    var coilXLeft = leftPinX + G.coilOffset, coilXRight = rightPinX - G.coilOffset;

    var pins = {};
    for (var k = 0; k < left; k++) pins[k + 1] = { x: leftPinX, y: left > 1 ? leftStartY + leftH * (k / (left - 1)) : leftStartY + leftH / 2, side: 'left' };
    for (var j = 0; j < right; j++) pins[total - j] = { x: rightPinX, y: right > 1 ? rightStartY + rightH * (j / (right - 1)) : rightStartY + rightH / 2, side: 'right' };
    for (var n = 1; n <= total; n++) {
      var p = pins[n];
      ops.push(circleOp(p.x, p.y, 3.6, { fill: COLOR.ink, stroke: COLOR.ink, width: 1.2 }));
      var nx = p.side === 'left' ? p.x - 14 : p.x + 14;
      ops.push(textOp(nx, p.y + 5, n, { size: 15, align: p.side === 'left' ? 'end' : 'start' }));
      obstacles.push(rect(p.x - 6, p.y - 6, p.x + 6, p.y + 6));
      obstacles.push(p.side === 'left' ? rect(p.x - 30, p.y - 10, p.x - 10, p.y + 7) : rect(p.x + 10, p.y - 10, p.x + 30, p.y + 7));
    }

    var placed = { left: [], right: [] };
    var wireOps = [], labelJobs = [], markOps = [];
    var stroke = { stroke: COLOR.wire, width: 2.4, cap: 'round' };
    function seg(x1, y1, x2, y2) { // مانع برای خط افقی/عمودی
      obstacles.push(rect(x1 - 2.5, y1 - 2.5, x2 + 2.5, y2 + 2.5));
    }

    windings.forEach(function (w) {
      var sS = pinSide(w.start, left), sE = pinSide(w.end, left);
      var pS = pins[w.start], pE = pins[w.end];

      if (sS === sE) {
        var side = sS;
        var yTop = Math.min(pS.y, pE.y), yBottom = Math.max(pS.y, pE.y);
        var list = placed[side];
        var overlap = list.filter(function (e) { return Math.max(e.yTop, yTop) < Math.min(e.yBottom, yBottom) - 1; });
        var nest = overlap.length ? 1 + Math.max.apply(null, overlap.map(function (e) { return e.nest; })) : 0;
        list.push({ yTop: yTop, yBottom: yBottom, nest: nest });
        var baseX = side === 'left' ? coilXLeft : coilXRight;
        var coilX = side === 'left' ? baseX + nest * G.nestStep : baseX - nest * G.nestStep;
        var dir = side === 'left' ? 1 : -1;

        wireOps.push(pathOp('M ' + f(pS.x) + ' ' + f(pS.y) + ' L ' + f(coilX) + ' ' + f(pS.y), stroke));
        wireOps.push(pathOp('M ' + f(coilX) + ' ' + f(pE.y) + ' L ' + f(pE.x) + ' ' + f(pE.y), stroke));
        seg(Math.min(pS.x, coilX), pS.y, Math.max(pS.x, coilX), pS.y);
        seg(Math.min(pE.x, coilX), pE.y, Math.max(pE.x, coilX), pE.y);
        wireOps.push(pathOp(coilVertical(coilX, yTop, yBottom, dir).d, stroke));
        obstacles.push(dir > 0 ? rect(coilX - 3, yTop - 4, coilX + G.bulge + 3, yBottom + 4) : rect(coilX - G.bulge - 3, yTop - 4, coilX + 3, yBottom + 4));

        // نقطه شروع: گوشهٔ فضای خالی کنار کویل، سمت پایه (نه روی سیم)
        var startTop = pS.y <= pE.y;
        var mx = coilX - dir * 10, my = startTop ? yTop + 8 : yBottom - 8;
        markOps.push(circleOp(mx, my, 4.3, { fill: COLOR.ink, stroke: COLOR.ink, width: 1.2 }));
        obstacles.push(rect(mx - 5, my - 5, mx + 5, my + 5));

        // مطابق نمونه کاربر: N بیرون کویل (سمت پایه‌ها) و تعداد دور کنار کویل (سمت هسته)، هر دو در وسط ارتفاع کویل
        var midC = (yTop + yBottom) / 2;
        labelJobs.push({ group: w.index, text: 'N' + w.index, color: COLOR.accent, tx: coilX - dir * 30, ty: midC, spanY: [yTop + 4, yBottom - 4], outsideSide: side, leadX: coilX + dir * G.bulge * 0.5, leadY: midC });
        labelJobs.push({ group: w.index, text: w.turns + 'T', color: COLOR.ink, tx: coilX + dir * (G.bulge + 24), ty: midC, spanY: [yTop + 4, yBottom - 4], outsideSide: side, leadX: coilX + dir * G.bulge * 0.5, leadY: midC });
        return;
      }

      // سیم‌پیچ دوسمتی (مدل A): کویل افقی در پنجره
      var pL = sS === 'left' ? pS : pE, pR = sS === 'left' ? pE : pS;
      var startIsLeft = sS === 'left';
      var yMid = (pL.y + pR.y) / 2;
      var xL = coilXLeft, xR = coilXRight;
      var ch = coilHorizontal(xL, xR, yMid, -1);
      wireOps.push(pathOp('M ' + f(pL.x) + ' ' + f(pL.y) + ' L ' + f(xL) + ' ' + f(pL.y) + ' L ' + f(xL) + ' ' + f(yMid), stroke));
      wireOps.push(pathOp('M ' + f(xR) + ' ' + f(yMid) + ' L ' + f(xR) + ' ' + f(pR.y) + ' L ' + f(pR.x) + ' ' + f(pR.y), stroke));
      wireOps.push(pathOp(ch.d, stroke));
      seg(pL.x, pL.y, xL, pL.y); seg(xL, Math.min(pL.y, yMid), xL, Math.max(pL.y, yMid));
      seg(xR, Math.min(pR.y, yMid), xR, Math.max(pR.y, yMid)); seg(xR, pR.y, pR.x, pR.y);
      obstacles.push(rect(xL - 3, yMid - G.bulge - 3, xR + 3, yMid + 3));
      var mxc = startIsLeft ? xL - 10 : xR + 10, myc = yMid + 10; // گوشه پایین کویل، فضای خالی
      markOps.push(circleOp(mxc, myc, 4.3, { fill: COLOR.ink, stroke: COLOR.ink, width: 1.2 }));
      obstacles.push(rect(mxc - 5, myc - 5, mxc + 5, myc + 5));
      labelJobs.push({ group: w.index, text: 'N' + w.index, color: COLOR.accent, tx: midX, ty: yMid + 16, spanY: [yMid - 10, yMid + 60], outsideSide: 'left', leadX: midX, leadY: yMid });
      labelJobs.push({ group: w.index, text: w.turns + 'T', color: COLOR.ink, tx: midX, ty: yMid - G.bulge - 14, spanY: [yMid - G.bulge - 60, yMid - 6], outsideSide: 'left', leadX: midX, leadY: yMid });
    });

    // ---- جای‌گذاری برچسب‌ها: نزدیک‌ترین جای خالی به هدف، بدون برخورد با هیچ خطی ----
    function segClear(x1, y1, x2, y2) {
      var len = Math.hypot(x2 - x1, y2 - y1), steps = Math.ceil(len / 2);
      for (var k = 0; k <= steps; k++) {
        var t = k / steps, px = x1 + (x2 - x1) * t, py = y1 + (y2 - y1) * t;
        if (Math.hypot(px - x1, py - y1) < 10 || Math.hypot(px - x2, py - y2) < 2) continue;
        for (var o = 0; o < obstacles.length; o++) {
          var ob = obstacles[o];
          if (px > ob.x1 - 1.5 && px < ob.x2 + 1.5 && py > ob.y1 - 1.5 && py < ob.y2 + 1.5) return false;
        }
      }
      return true;
    }
    function outsideSpot(job, taken) {
      var w = job.text.length * 8.4 + 6, best = null, cands = [], y, x;
      for (y = coreTop + 10; y <= coreBottom - 10; y += 4) {
        cands.push({ px: coreLeft - 22, py: y, side: 'left' });
        cands.push({ px: coreRight + 22, py: y, side: 'right' });
      }
      for (x = coreLeft + 10; x <= coreRight - 10; x += 10) {
        cands.push({ px: x, py: coreTop - 16, side: 'top' });
        cands.push({ px: x, py: coreBottom + 16, side: 'bottom' });
      }
      cands.forEach(function (c) {
        var r, tx, ty, align;
        if (c.side === 'left') { tx = c.px - 6; ty = c.py + 4; align = 'end'; r = rect(tx - w, c.py - 10, tx, c.py + 4); }
        else if (c.side === 'right') { tx = c.px + 6; ty = c.py + 4; align = 'start'; r = rect(tx, c.py - 10, tx + w, c.py + 4); }
        else { tx = c.px; ty = c.py + 4; align = 'middle'; r = rect(tx - w / 2, c.py - 10, tx + w / 2, c.py + 4); }
        if (taken.some(function (o) { return hit(r, o, 2); })) return;
        if (obstacles.some(function (o) { return hit(r, o, 2); })) return;
        if (!segClear(c.px, c.py, job.leadX, job.leadY)) return;
        var len = Math.hypot(c.px - job.leadX, c.py - job.leadY);
        if (!best || len < best.len) best = { px: c.px, py: c.py, tx: tx, ty: ty, align: align, rect: r, len: len };
      });
      return best;
    }

    function fallbackSpot(job, taken) {
      var w = job.text.length * 8.4 + 6, cands = [], x;
      for (x = coreLeft + 10; x <= coreRight - 10; x += 6) {
        cands.push({ px: x, py: coreTop - 16 }); cands.push({ px: x, py: coreBottom + 16 });
      }
      cands.sort(function (a1, a2) { return Math.abs(a1.px - job.leadX) - Math.abs(a2.px - job.leadX); });
      for (var c = 0; c < cands.length; c++) {
        var r = rect(cands[c].px - w / 2, cands[c].py - 10, cands[c].px + w / 2, cands[c].py + 4);
        if (!taken.some(function (o) { return hit(r, o, 2); })) return { px: cands[c].px, py: cands[c].py, tx: cands[c].px, ty: cands[c].py + 4, align: 'middle', rect: r };
      }
      return null;
    }
    var placedRects = [];
    // هر سیم‌پیچ (N و تعداد دور) یک گروه است: یا هر دو داخل کادر جا می‌شوند، یا هر دو بیرون با خط‌چین
    var groups = {}, groupOrder = [];
    labelJobs.forEach(function (job) {
      if (!groups[job.group]) { groups[job.group] = []; groupOrder.push(job.group); }
      groups[job.group].push(job);
    });
    function findSpot(job, taken) {
      var cands = [];
      var sy1 = job.spanY ? job.spanY[0] : coreTop + 14, sy2 = job.spanY ? job.spanY[1] : coreBottom - 14;
      var xOffsets = job.spanY ? [0, -4, 4, -8, 8, -12, 12] : [0, -12, 12, -24, 24];
      xOffsets.forEach(function (dx) {
        var x = job.tx + dx;
        if (x < coreLeft + 6 || x > coreRight - 6) return;
        for (var y = sy1; y <= sy2; y += G.gridStep / 2) {
          cands.push({ x: x, y: y, d: Math.abs(dx) * 3 + Math.abs(y - job.ty) });
        }
      });
      cands.sort(function (p1, p2) { return p1.d - p2.d; });
      for (var c = 0; c < cands.length; c++) {
        var v = labelVariant(cands[c].x, cands[c].y, job.text, job.color);
        var r = v.rect;
        if (r.x1 < coreLeft + 4 || r.x2 > coreRight - 4 || r.y1 < coreTop + 4 || r.y2 > coreBottom - 4) continue;
        var bad = obstacles.some(function (o) { return hit(r, o, G.pad); }) || taken.some(function (o) { return hit(r, o, 2); });
        if (!bad) return v;
      }
      return null;
    }
    groupOrder.forEach(function (gk) {
      var jobs = groups[gk], taken = placedRects.slice(), found = [];
      for (var j = 0; j < jobs.length && found.length === j; j++) {
        var v = findSpot(jobs[j], taken);
        if (v) { found.push(v); taken.push(v.rect); }
      }
      if (found.length === jobs.length) {
        found.forEach(function (v) { placedRects.push(v.rect); v.ops.forEach(function (o) { ops.push(o); }); });
        return;
      }
      // جا نشد: هر دو برچسب بیرون کادر، با خط‌چین که از روی هیچ سیم یا کویل یا متنی عبور نکند
      jobs.forEach(function (job) {
        var best = outsideSpot(job, placedRects);
        if (best) {
          placedRects.push(best.rect);
          wireOps.push(pathOp('M ' + f(best.px) + ' ' + f(best.py) + ' L ' + f(job.leadX) + ' ' + f(job.leadY), { stroke: COLOR.muted, width: 1, dash: [3, 3] }));
        } else {
          // هیچ مسیر بدون برخورد پیدا نشد: برچسب بیرون و بدون خط راهنما نوشته می‌شود تا گم نشود
          best = fallbackSpot(job, placedRects);
          if (!best) return;
          placedRects.push(best.rect);
        }
        ops.push(textOp(best.tx, best.ty, job.text, { size: 13, weight: 700, color: job.color, align: best.align }));
      });
    });

    ops = ops.concat(wireOps, markOps);

    // The specification table is intentionally rendered by React below the diagrams,
    // not inside image 2. This keeps the top-view drawing large and clean.

    return { width: width, height: height, ops: ops, errors: wRes.errors, windings: windings, pins: pins, total: total };
  }

  function escapeXml(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

  function toSVG(scene) {
    var out = ['<svg xmlns="http://www.w3.org/2000/svg" width="' + scene.width + '" height="' + scene.height + '" viewBox="0 0 ' + scene.width + ' ' + scene.height + '">',
      '<rect width="100%" height="100%" fill="' + COLOR.paper + '"/>'];
    scene.ops.forEach(function (o) {
      if (o.t === 'path') {
        out.push('<path d="' + o.d + '" fill="' + (o.fill || 'none') + '"' +
          (o.stroke ? ' stroke="' + o.stroke + '" stroke-width="' + o.width + '" stroke-linecap="' + o.cap + '" stroke-linejoin="round"' +
            (o.dash ? ' stroke-dasharray="' + o.dash.join(' ') + '"' : '') : '') + '/>');
      } else if (o.t === 'circle') {
        out.push('<circle cx="' + f(o.x) + '" cy="' + f(o.y) + '" r="' + o.r + '"' + (o.fill ? ' fill="' + o.fill + '"' : '') +
          (o.stroke ? ' stroke="' + o.stroke + '" stroke-width="' + o.width + '"' : '') + '/>');
      } else if (o.t === 'text') {
        var anchor = o.align === 'middle' ? 'middle' : (o.align === 'end' ? 'end' : 'start');
        out.push('<text x="' + f(o.x) + '" y="' + f(o.y) + '" font-family="' + FONT + '" font-size="' + o.size + '" font-weight="' + o.weight +
          '" fill="' + o.color + '" text-anchor="' + anchor + '"' + (o.halo ? ' stroke="' + COLOR.paper + '" stroke-width="4" paint-order="stroke"' : '') + '>' + escapeXml(o.s) + '</text>');
      }
    });
    out.push('</svg>');
    return out.join('\n');
  }

  function drawToCanvas(ctx, scene, scale) {
    scale = scale || 1;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.fillStyle = COLOR.paper;
    ctx.fillRect(0, 0, scene.width, scene.height);
    scene.ops.forEach(function (o) {
      if (o.t === 'path') {
        var p = new Path2D(o.d);
        if (o.fill) { ctx.fillStyle = o.fill; ctx.fill(p); }
        if (o.stroke) {
          ctx.strokeStyle = o.stroke; ctx.lineWidth = o.width; ctx.lineCap = o.cap; ctx.lineJoin = 'round';
          ctx.setLineDash(o.dash || []); ctx.stroke(p); ctx.setLineDash([]);
        }
      } else if (o.t === 'circle') {
        ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2);
        if (o.fill) { ctx.fillStyle = o.fill; ctx.fill(); }
        if (o.stroke) { ctx.strokeStyle = o.stroke; ctx.lineWidth = o.width; ctx.stroke(); }
      } else if (o.t === 'text') {
        ctx.font = o.weight + ' ' + o.size + 'px ' + FONT;
        ctx.textAlign = o.align === 'middle' ? 'center' : (o.align === 'end' ? 'right' : 'left');
        if (o.halo) { ctx.strokeStyle = COLOR.paper; ctx.lineWidth = 4; ctx.lineJoin = 'round'; ctx.strokeText(o.s, o.x, o.y); }
        ctx.fillStyle = o.color; ctx.fillText(o.s, o.x, o.y);
      }
    });
  }

  return { G: G, COLOR: COLOR, LIMITS: LIMITS, parsePins: parsePins, validatePins: validatePins, validateWindings: validateWindings,
    buildScene: buildScene, toSVG: toSVG, drawToCanvas: drawToCanvas };
})();
window.AryDiagram = TransformerDiagram;
const AryDiagram = TransformerDiagram;
  const format = (value, digits = 1) => new Intl.NumberFormat('fa-IR', { minimumFractionDigits: 0, maximumFractionDigits: digits }).format(Number(value || 0));
  const escapeXml = (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  window.AryDiagramFill = buildWindowFillSvg;
  window.AryDiagramPin = buildPinDiagramSvg;

function buildWindowFillSvg(bobbin, engineering, options = {}) {
  const rows = engineering?.rows || [];
  const width = 820;
  const height = 430;
  const frame = { x: 120, y: 72, width: 580, height: 278 };
  const fontFamily = "'Aryaman Vazirmatn',Vazirmatn,Tahoma,Arial,sans-serif";
  const en = options.lang === 'en';
  const T = en
    ? { title: 'Window Fill — Winding Build-up', free: 'Free window space', legend: 'One band per winding · gold strip = layer insulation', radial: (v) => `Radial fill ${v}`, over: (v) => `OVERFILL · ${v}`, aria: 'Window fill diagram', placeholder: 'Run a valid calculation to draw this diagram.' }
    : { title: 'نقشه پرشدگی سیم‌پیچ‌ها', free: 'فضای آزاد پنجره', legend: 'هر نوار یک سیم‌پیچ یک‌تکه است؛ نوار طلایی عایق بین سیم‌پیچ‌هاست.', radial: (v) => `پرشدگی شعاعی ${v}`, over: (v) => `بیش‌ازحد مجاز · ${v}`, aria: 'نقشه پرشدگی سیم‌پیچ‌ها', placeholder: 'برای رسم نقشه، محاسبه معتبر لازم است.' };
  if (!bobbin || !rows.length) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="${T.aria}"><rect width="100%" height="100%" rx="20" fill="#fbfaf6"/><text x="410" y="215" text-anchor="middle" font-family="${fontFamily}" font-size="16" fill="#5b6670">${T.placeholder}</text></svg>`;
  }

  const rowShareTotal = rows.reduce((sum, row) => sum + Math.max(0, Number(row.window_share_percent || 0)), 0);
  const radialPercent = Number.isFinite(Number(engineering?.radial_percent))
    ? Math.max(0, Number(engineering.radial_percent))
    : rowShareTotal;
  const displayedPercent = Math.min(100, radialPercent);
  const consumedHeight = frame.height * displayedPercent / 100;
  const separatorCount = Math.max(0, rows.length - 1);
  // The separator is a visual production aid. Keep it clearly readable while
  // preserving at least two pixels for every winding in very small drawings.
  const availableForSeparators = Math.max(0, consumedHeight - rows.length * 2);
  const separator = separatorCount ? Math.min(8, availableForSeparators / separatorCount) : 0;
  const bandSpace = Math.max(0, consumedHeight - separator * separatorCount);
  const weights = rows.map((row) => {
    const build = Number(row.build_mm);
    if (Number.isFinite(build) && build > 0) return build;
    const allocated = Number(row.allocated_build_mm);
    const before = Number(row.separator_before_mm || 0);
    if (Number.isFinite(allocated) && allocated > before) return allocated - before;
    return Math.max(0, Number(row.window_share_percent || 0));
  });
  const weightTotal = weights.reduce((sum, value) => sum + value, 0) || 1;
  let cursor = frame.y + frame.height;
  const bands = [];

  rows.forEach((row, index) => {
    const bandHeight = bandSpace * weights[index] / weightTotal;
    cursor -= bandHeight;
    bands.push(`<rect class="winding-band" data-winding-index="${index + 1}" data-winding-name="${escapeXml(row.name)}" x="${frame.x}" y="${cursor.toFixed(3)}" width="${frame.width}" height="${bandHeight.toFixed(3)}" fill="${escapeXml(row.color || '#3976e8')}"/>`);
    if (bandHeight >= 26) {
      const shareLabel = `N${index + 1} · ${(bandSpace ? (weights[index] / weightTotal) * 100 : 0).toFixed(1)}%`;
      bands.push(`<text x="${(frame.x + frame.width / 2).toFixed(2)}" y="${(cursor + bandHeight / 2 + 5).toFixed(2)}" text-anchor="middle" font-family="${fontFamily}" font-size="13.5" font-weight="800" fill="#ffffff" opacity="0.96">${escapeXml(shareLabel)}</text>`);
    }
    if (index < rows.length - 1) {
      cursor -= separator;
      bands.push(`<rect class="insulation-separator" data-insulation-mm="${escapeXml(engineering.insulation_mm || '')}" x="${frame.x}" y="${cursor.toFixed(3)}" width="${frame.width}" height="${separator.toFixed(3)}" rx="2" fill="#f5c542" stroke="#a97712" stroke-width="1"/>`);
    }
  });

  const freeHeight = Math.max(0, cursor - frame.y);
  const freeLabel = freeHeight >= 38
    ? `<text x="410" y="${(frame.y + freeHeight / 2 + 5).toFixed(2)}" text-anchor="middle" font-family="${fontFamily}" font-size="13" fill="#758390">${T.free}</text>`
    : '';
  const overfillBoundary = radialPercent > 100
    ? `<line class="overfill-boundary" x1="${frame.x}" y1="${frame.y + 2}" x2="${frame.x + frame.width}" y2="${frame.y + 2}" stroke="#a5453f" stroke-width="4" stroke-dasharray="12 6"/>`
    : '';
  const pctText = en ? `${formatEn(radialPercent)}%` : `${format(radialPercent, 1)}٪`;
  const radialLabel = radialPercent > 100 ? T.over(pctText) : T.radial(pctText);
  const bwText = Number.isFinite(Number(bobbin.window_width_mm)) && Number(bobbin.window_width_mm) > 0 ? (en ? `BW ${formatEn(bobbin.window_width_mm, 2)} mm` : `BW ${format(bobbin.window_width_mm, 2)} mm`) : 'BW';
  const hwText = Number.isFinite(Number(bobbin.window_height_mm)) && Number(bobbin.window_height_mm) > 0 ? (en ? `HW ${formatEn(bobbin.window_height_mm, 2)} mm` : `HW ${format(bobbin.window_height_mm, 2)} mm`) : 'HW';
  const dims = `<g font-family="${fontFamily}" font-size="12.5" fill="#4c5a68"><line x1="${frame.x}" y1="${frame.y - 8}" x2="${frame.x + frame.width}" y2="${frame.y - 8}" stroke="#8e9ba8" stroke-width="1"/><line x1="${frame.x}" y1="${frame.y - 12}" x2="${frame.x}" y2="${frame.y - 4}" stroke="#8e9ba8" stroke-width="1"/><line x1="${frame.x + frame.width}" y1="${frame.y - 12}" x2="${frame.x + frame.width}" y2="${frame.y - 4}" stroke="#8e9ba8" stroke-width="1"/><text x="${(frame.x + frame.width / 2).toFixed(2)}" y="${frame.y - 14}" text-anchor="middle">${bwText}</text><line x1="${frame.x + frame.width + 10}" y1="${frame.y}" x2="${frame.x + frame.width + 10}" y2="${frame.y + frame.height}" stroke="#8e9ba8" stroke-width="1"/><line x1="${frame.x + frame.width + 6}" y1="${frame.y}" x2="${frame.x + frame.width + 14}" y2="${frame.y}" stroke="#8e9ba8" stroke-width="1"/><line x1="${frame.x + frame.width + 6}" y1="${frame.y + frame.height}" x2="${frame.x + frame.width + 14}" y2="${frame.y + frame.height}" stroke="#8e9ba8" stroke-width="1"/><text x="${(frame.x + frame.width + 22).toFixed(2)}" y="${(frame.y + frame.height / 2).toFixed(2)}" text-anchor="middle" transform="rotate(90 ${(frame.x + frame.width + 22).toFixed(2)} ${(frame.y + frame.height / 2).toFixed(2)})">${hwText}</text></g>`;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="${T.aria}" preserveAspectRatio="xMidYMid meet"><rect width="100%" height="100%" rx="20" fill="#fbfaf6"/><text x="410" y="34" text-anchor="middle" font-family="${fontFamily}" font-size="17" font-weight="700" fill="#16325c">${T.title}</text><rect x="94" y="50" width="632" height="22" rx="7" fill="#25374e"/><rect x="94" y="350" width="632" height="22" rx="7" fill="#25374e"/><rect x="96" y="66" width="24" height="290" rx="7" fill="#354a63"/><rect x="700" y="66" width="24" height="290" rx="7" fill="#354a63"/><rect x="${frame.x}" y="${frame.y}" width="${frame.width}" height="${frame.height}" fill="#edf2f5" stroke="#8e9ba8" stroke-width="2"/>${freeLabel}${bands.join('')}${overfillBoundary}${dims}<g font-family="${fontFamily}"><text x="120" y="402" font-size="12" fill="#5b6670">${T.legend}</text><text x="700" y="402" text-anchor="end" font-size="14" font-weight="700" fill="${radialPercent > 100 ? '#a5453f' : '#16325c'}">${radialLabel}</text></g></svg>`;
}


const formatEn = (value, digits = 1) => new Intl.NumberFormat('en-US', {
  minimumFractionDigits: 0,
  maximumFractionDigits: digits,
}).format(Number(value || 0));

/** Image 2: fixed top view, enlarged, with no embedded specification table. */
function buildPinDiagramSvg(bobbin, engineering, options = {}) {
  const rows = engineering?.rows || [];
  if (!bobbin || !rows.length) return '';
  const scene = AryDiagram.buildScene({
    left: Number(bobbin.pins_left),
    right: Number(bobbin.pins_right),
    view: 'top',
    allowCrossSide: true,
    title: options.lang === 'en' ? 'Top View — Pins & Windings' : undefined,
    windings: rows.map((row, index) => ({
      name: options.lang === 'en' ? `N${index + 1}` : row.name,
      start: Number(row.start_pin),
      end: Number(row.end_pin),
      turns: Number(row.turns),
      wire: Number(row.wire_diameter_mm).toFixed(2),
      strand: Number(row.strands),
      layer: Number(row.calculated_layers),
      direction: row.direction === 'ccw' ? 'CCW' : 'CW',
      insulation: `${format(engineering.insulation_mm, 2)} mm`,
    })),
  });
  if (!scene.width) return '';
  return AryDiagram.toSVG(scene)
    .replace(/\swidth="[^"]*"/, '')
    .replace(/\sheight="[^"]*"/, '')
    .replace('<svg ', '<svg role="img" aria-label="نمای بالای پایه و سیم‌پیچی" preserveAspectRatio="xMidYMin meet" ');
}


  /* ---------- shared helpers ---------- */
  const escA = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const enNum = (value, digits = 3) => Number.isFinite(Number(value)) ? new Intl.NumberFormat('en-US', { maximumFractionDigits: digits }).format(Number(value)) : '—';
  const enInt = (value) => new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Math.max(0, Number(value) || 0));
  const faNum = (value, digits = 3) => Number.isFinite(Number(value)) ? new Intl.NumberFormat('fa-IR', { maximumFractionDigits: digits }).format(Number(value)) : '—';
  const irr = (value) => Number.isFinite(Number(value)) && Number(value) > 0 ? `${enInt(value)} IRR` : '—';
  const enJalaliDate = new Intl.DateTimeFormat('en-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' });
  const valueOrDash = (value) => value === null || value === undefined || value === '' ? '—' : escA(value);
  const TON = { isolation: 'عایق ایمنی', pfc: 'اصلاح ضریب توان (PFC)', digital: 'کنترل دیجیتال', communication: 'ارتباطات و پایش', protection: 'زنجیره حفاظت', emi: 'سازگاری الکترومغناطیسی (EMI)', thermal: 'مدیریت حرارتی' };

  /* ---------- refined print base 136.0.1 styles ----------
     Dictated refinements: smaller bold headings, brighter faint words,
     richer frames and completed details. */
  const reportCss = `
@page{size:A4;margin:0}
*{margin:0;padding:0;box-sizing:border-box}
body{background:#fff;font-family:Arial,'Aryaman Vazirmatn',Vazirmatn,Tahoma,sans-serif;color:#1c2b3a;font-synthesis:none;text-rendering:optimizeLegibility;-webkit-font-smoothing:antialiased}
.page{width:210mm;min-height:296mm;padding:9mm 9mm 7mm;background:#fff;overflow:hidden;page-break-after:always;position:relative;display:flex;flex-direction:column}
.page:last-child{page-break-after:auto}
.ds-head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #1d3a5f;padding-bottom:3.5mm;margin-bottom:3mm;position:relative}
.ds-head:after{content:'';position:absolute;bottom:-1.8mm;right:0;left:0;height:.6mm;background:linear-gradient(90deg,#f2b705 0 28%,#1d3a5f 28%)}
.ds-head h1{color:#1d3a5f;font-size:14.5pt;font-weight:800;letter-spacing:-.2px}
.ds-head p{margin-top:1.1mm;font-size:9pt;color:#3d5064}
.ds-head p b{color:#1d3a5f}
.ds-head p .secret{color:#a5453f}
.ds-head.rtl{direction:rtl}
.ds-logo img{max-height:12mm}
.logo-text{text-align:center}
.logo-text b{display:block;font-size:14pt;font-weight:900;color:#1d3a5f;line-height:1}
.logo-text b span{color:#f2b705}
.logo-text i{display:block;font-size:9pt;font-weight:800;color:#1d3a5f;font-style:normal;letter-spacing:1px}
.ds-ltr{direction:ltr}
.ds-ltr .ds-sec,.ds-ltr .ds-cols,.ds-ltr .ds-diagrams{direction:ltr}
.ds-sec{display:flex;align-items:center;gap:2.2mm;margin:3.6mm 0 1.8mm}
.ds-sec i{min-width:5mm;height:5mm;border-radius:50%;background:#1d3a5f;color:#fff;font-size:8pt;font-weight:800;display:flex;align-items:center;justify-content:center;padding:0 1mm}
*,*::before,*::after{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
.ds-sec h2{font-size:9.5pt;font-weight:800;color:#1d3a5f;white-space:nowrap}
.ds-sec .line{flex:1;height:.6mm;background:linear-gradient(90deg,#b9c8dc,#d7dee8);border-radius:1mm}
.ds-sec-cap{font-size:7.6pt;color:#3d5871;margin:-.8mm 0 1.6mm 7mm;font-weight:600}
.ds-cols{display:grid;grid-template-columns:1fr 1fr;gap:5mm}
.ds-wrap{border-radius:2.6mm;overflow:hidden;border:.35mm solid #9fb0c5;box-shadow:0 .5mm 1.5mm rgba(29,58,95,.10)}
.ds-wrap.half{max-width:150mm}
table{border-collapse:collapse}
.ds-info{width:100%;font-size:8.5pt}
.ds-info thead th{background:linear-gradient(180deg,#28517f,#1d3a5f);color:#fff;font-weight:700;padding:1.6mm 3mm;text-align:left}
.ds-info thead th+th{border-left:.3mm solid #2d4d76}
.ds-info td{border-top:.3mm solid #dde4ee;padding:1.5mm 3mm}
.ds-info tr:nth-child(even) td{background:#f3f7fc}
.ds-info td.k{width:44%;color:#33475c;font-weight:700}
.ds-info td.v{font-weight:800}
.ds-wind{width:100%;font-size:8.2pt;text-align:center}
.ds-wind thead th{background:linear-gradient(180deg,#28517f,#1d3a5f);color:#fff;padding:1.8mm 1.5mm;font-weight:700;border-left:.3mm solid #2d4d76}
.ds-wind thead th:last-child{border-left:none}
.ds-wind td{border-top:.3mm solid #dde4ee;border-left:.3mm solid #e4eaf2;padding:1.6mm 1.2mm}
.ds-wind td:last-child{border-left:none}
.ds-wind tr:nth-child(even) td{background:#f3f7fc}
.ds-wind td.name{font-weight:800;color:#1d3a5f;white-space:nowrap}
.dir{display:inline-block;min-width:8mm;border-radius:3mm;background:#e8eef7;color:#1d3a5f;font-weight:800;font-size:7.5pt;padding:.4mm 1.8mm}
.ds-diagrams{display:grid;grid-template-columns:1fr 1fr;gap:3.5mm;align-items:stretch}
.ds-diagram{border:.4mm solid #aebfd4;border-radius:3mm;background:#fdfcf7;padding:2mm;display:flex;flex-direction:column;height:72mm;box-shadow:0 .6mm 1.8mm rgba(29,58,95,.12)}
.ds-diagram h3{font-size:8.8pt;color:#1d3a5f;font-weight:800;text-align:center;margin-bottom:1.2mm;border-bottom:.3mm solid #e3d9b8;padding-bottom:.8mm}
.ds-diagram .ds-fig{flex:1;min-height:0;display:flex;align-items:center;justify-content:center}
.ds-diagram svg{width:100%;height:100%;max-height:100%}
.ds-legend{display:flex;flex-wrap:wrap;gap:1mm 2.5mm;margin-top:1mm;font-size:7.2pt;color:#16304d;font-weight:700;justify-content:center}
.ds-legend span{display:inline-flex;align-items:center;gap:.8mm;white-space:nowrap}
.ds-legend i{width:3.2mm;height:2.4mm;border-radius:.6mm;display:inline-block}
.ds-legend span.gold i{background:#f5c542;border:.25mm solid #a97712}
.ds-cap{margin:1mm 0 0;font-size:7.2pt;color:#33506c;line-height:1.5;text-align:center;font-weight:500}
.ds-opt{background:#fff6dc;border:.4mm solid #e3c36a;border-radius:2.5mm;padding:1.5mm 2mm 2mm;margin-bottom:3mm}
.ds-opt .ds-sec h2{color:#7a5a10}
.ds-none{font-size:8pt;color:#5f7a94;text-align:center;padding:6mm 0}
.ds-qc{width:100%;font-size:8.5pt;text-align:center}
.ds-qc thead th{background:linear-gradient(180deg,#28517f,#1d3a5f);color:#fff;padding:1.6mm 2.5mm;font-weight:700;border-left:.3mm solid #2d4d76}
.ds-qc td{border-top:.3mm solid #dde4ee;border-left:.3mm solid #e4eaf2;padding:1.5mm 2.5mm}
.ds-summary{border-radius:3mm;overflow:hidden;border:.35mm solid #9fb0c5;margin-top:1mm;box-shadow:0 .6mm 1.8mm rgba(29,58,95,.12)}
.ds-summary .bars{display:grid;grid-template-columns:repeat(3,1fr);background:#fff}
.ds-summary .cell{padding:2.4mm 2mm;text-align:center;border-left:.3mm solid #e4eaf2}
.ds-summary .cell:last-child{border-left:none}
.ds-summary .cell small{display:block;font-size:7.2pt;color:#33506c;margin-bottom:1mm;font-weight:700;letter-spacing:.4px}
.ds-summary .cell b{font-size:10pt;color:#1d3a5f;font-weight:800}
.ds-summary .price{display:grid;grid-template-columns:1fr 1fr 1.3fr;background:#1d3a5f;color:#fff}
.ds-summary .price>div{padding:2.4mm 2mm;text-align:center;border-left:.3mm solid #2d4d76}
.ds-summary .price>div:last-child{border-left:none}
.ds-summary .price small{display:block;font-size:7.2pt;opacity:.92;margin-bottom:1mm;font-weight:700;letter-spacing:.4px}
.ds-summary .price b{font-size:10pt;font-weight:800}
.ds-summary .price .grand{background:#f2b705;color:#233246}
.ds-summary .price .grand small{color:#5c4a00}
.ds-foot{margin-top:auto;border-top:.7mm solid #1d3a5f;padding-top:2mm;display:flex;justify-content:center;gap:4mm;font-size:8.5pt;color:#2e4258}
.ds-foot b{color:#1d3a5f}
/* ---------- board one-sheet (Persian) ---------- */
.br-page{direction:rtl;font-family:'Aryaman Vazirmatn',Vazirmatn,Tahoma,Arial,sans-serif}
.br-page .ds-head h1{font-size:14pt}
.br-grid{display:grid;grid-template-columns:1fr 1fr;gap:5mm}
.br-lines{width:100%;font-size:8.6pt;direction:rtl}
.br-lines thead th{background:linear-gradient(180deg,#28517f,#1d3a5f);color:#fff;padding:1.7mm 2.8mm;text-align:right;font-weight:700}
.br-lines td{border-top:.3mm solid #dde4ee;padding:1.5mm 2.8mm}
.br-lines td:last-child{font-weight:800;text-align:left;direction:ltr;white-space:nowrap}
.br-lines tr:nth-child(even) td{background:#f3f7fc}
.br-lines tr.total td{background:#eef3fa;font-weight:800}
.br-total{margin-top:4mm;border-radius:3mm;background:linear-gradient(135deg,#1d3a5f,#2a5388);color:#fff;padding:4.5mm 5mm;display:flex;justify-content:space-between;align-items:center}
.br-total small{display:block;font-size:8pt;opacity:.85;margin-bottom:1mm;font-weight:700}
.br-total b{font-size:13.5pt;font-weight:900;color:#f8d348}
.br-total .cell{text-align:center;padding:0 4mm;border-left:.3mm solid #3d6598}
.br-total .cell:last-child{border-left:none}
.br-note{margin-top:3.5mm;border:.35mm dashed #b9c4d4;border-radius:2.5mm;padding:1.8mm 3.5mm;font-size:7.8pt;color:#33506c;line-height:1.7}
`;

  function reportHeader(title, subtitle, docCode, confidential = false) {
    return `<header class="ds-head"><div class="ds-title"><h1>${escA(title)}</h1><p>${escA(subtitle)} &nbsp;|&nbsp; Document ID: <b>${escA(docCode)}</b>${confidential ? ' &nbsp;|&nbsp; <b class="secret">Staff Only</b>' : ''}</p></div><div class="ds-logo"><div class="logo-text"><b>U<span>S</span></b><i>aryaman</i></div></div></header>`;
  }
  function sectionTitle(index, title, caption = '') {
    return `<div class="ds-sec"><i>${escA(index)}</i><h2>${escA(title)}</h2><span class="line"></span></div>${caption ? `<div class="ds-sec-cap">${escA(caption)}</div>` : ''}`;
  }
  function footer(docCode, page, total) {
    return `<footer class="ds-foot"><b>${escA(docCode)}</b><span>|</span><span>Page ${enNum(page, 0)} / ${enNum(total, 0)}</span></footer>`;
  }
  function infoTable(rows) {
    return `<div class="ds-wrap"><table class="ds-info"><thead><tr><th>Item</th><th>Value</th></tr></thead><tbody>${rows.map(([k, v]) => `<tr><td class="k">${escA(k)}</td><td class="v">${v}</td></tr>`).join('')}</tbody></table></div>`;
  }
  function windingsTableRows(engineering) {
    const rows = engineering?.rows || [];
    const wraps = Number(engineering?.insulation_wraps_per_layer ?? 3);
    return rows.map((row) => `<tr><td class="name">N${enNum(row.line_no, 0)} · ${escA(row.name || '')}</td><td>${enNum(row.start_pin, 0)}</td><td>${enNum(row.end_pin, 0)}</td><td>${enNum(row.turns, 0)}</td><td>${enNum(row.wire_diameter_mm, 2)}${row.awg ? ` (AWG ${enNum(row.awg, 0)})` : ''}</td><td>${enNum(row.strands, 0)}</td><td>${enNum(row.calculated_layers, 0)}</td><td><span class="dir">${row.direction === 'ccw' ? 'CCW' : 'CW'}</span></td><td>${enNum(wraps, 0)}</td></tr>`).join('');
  }
  function orderSummary(engineering, publicResult, quantity) {
    return `<div class="ds-summary"><div class="bars">
    <div class="cell"><small>WINDOW OCCUPANCY</small><b>${enNum(engineering?.occupancy_percent)}%</b></div>
    <div class="cell"><small>COPPER WIRE WEIGHT</small><b>${enNum(engineering?.copper_weight_per_unit_g)} g / pc</b></div>
    <div class="cell"><small>ORDER QUANTITY</small><b>${enInt(quantity)} pcs</b></div>
  </div><div class="price">
    <div><small>UNIT PRICE</small><b>${irr(publicResult?.unit_sale_rial)}</b></div>
    <div><small>SETUP FEE</small><b>${Number(publicResult?.setup_fee_rial) > 0 ? irr(publicResult?.setup_fee_rial) : '—'}</b></div>
    <div class="grand"><small>TOTAL PRICE</small><b>${irr(publicResult?.total_sale_rial)}</b></div>
  </div></div>`;
  }
  function optionalSections(testData) {
    const t = testData || {};
    const indFilled = [t.ind_primary, t.ind_leakage, t.ind_secondary].some((v) => String(v || '').trim());
    const testFilled = [t.turns_ratio, t.hipot, t.dcr_primary, t.dcr_secondary, t.dcr_auxiliary].some((v) => String(v || '').trim());
    let html = '';
    if (indFilled) {
      html += `<div class="ds-opt">${sectionTitle(5, 'Inductance', 'Optional — provided by the customer')}<div class="ds-wrap half"><table class="ds-qc"><thead><tr><th>Inductance</th><th>Measurement</th><th>Value</th></tr></thead><tbody>
      <tr><td>Primary</td><td>${escA(t.ind_primary_condition || '10 kHz · 1V')}</td><td>${escA(t.ind_primary || '—')}</td></tr>
      <tr><td>Leakage</td><td>${escA(t.ind_leakage_condition || '—')}</td><td>${escA(t.ind_leakage || '—')}</td></tr>
      <tr><td>Secondary</td><td>${escA(t.ind_secondary_condition || '—')}</td><td>${escA(t.ind_secondary || '—')}</td></tr>
    </tbody></table></div></div>`;
    }
    if (testFilled) {
      html += `<div class="ds-opt">${sectionTitle('5.1', 'Electrical Test', 'Optional — provided by the customer')}<div class="ds-wrap half"><table class="ds-qc"><thead><tr><th>Item</th><th>Value</th><th>Test Condition</th></tr></thead><tbody>
      <tr><td>Turns Ratio</td><td>${escA(t.turns_ratio || '—')}</td><td>${escA(t.turns_ratio_condition || '—')}</td></tr>
      <tr><td>Hi-Pot (Insulation Test)</td><td>${escA(t.hipot || '—')}</td><td>${escA(t.hipot_condition || '—')}</td></tr>
      <tr><td>DCR – Primary</td><td>${escA(t.dcr_primary || '—')}</td><td>${escA(t.dcr_primary_condition || '—')}</td></tr>
      <tr><td>DCR – Secondary</td><td>${escA(t.dcr_secondary || '—')}</td><td>${escA(t.dcr_secondary_condition || '—')}</td></tr>
      <tr><td>DCR – Auxiliary</td><td>${escA(t.dcr_auxiliary || '—')}</td><td>${escA(t.dcr_auxiliary_condition || '—')}</td></tr>
    </tbody></table></div></div>`;
    }
    return html;
  }
  function datasheetPage(data) {
    const docCode = { model: data.core?.model_code || 'AM', doc: data.code || 'PREVIEW' };
    const createdAt = data.createdAt ? new Date(data.createdAt) : new Date();
    const bobbin = data.bobbin || {};
    const coreRows = [
      ['Core Type', valueOrDash(data.core?.model_code)],
      ['Family', valueOrDash(data.core?.family)],
      ['Core Material', valueOrDash(data.core?.material)],
      ['Bobbin', bobbin.pins_left ? `${enNum(bobbin.pins_left, 0)}+${enNum(bobbin.pins_right, 0)} ${escA(bobbin.mount_orientation || '')}` : valueOrDash(data.bobbinLabel)],
      ['Ae', Number(data.core?.effective_area_mm2) > 0 ? `${enNum(data.core.effective_area_mm2)} mm²` : '—'],
      ...(data.hasGap ? [['Air Gap', valueOrDash(data.core?.assembly_method === 'ماشینی' ? 'Yes (machine)' : 'Yes')]] : []),
    ];
    return `<section class="page ds-ltr">
    ${reportHeader('Switching Transformer Datasheet', `Model: <b>${escA(docCode.model)}</b>`, docCode.doc)}
    <div class="ds-cols">
      <div>${sectionTitle(1, 'Basic Information')}${infoTable([
        ['Document ID', escA(docCode.doc)],
        ['Project', escA(data.projectTitle || '—')],
        ['Customer', escA(data.customerName || '—')],
        ['Designer', 'aryaman'],
        ['Date', escA(enJalaliDate.format(createdAt))],
        ['Order Quantity', `${enInt(data.quantity)} pcs`],
      ])}</div>
      <div>${sectionTitle(2, 'Core Specifications')}${infoTable(coreRows)}</div>
    </div>
    ${sectionTitle(3, 'Winding Specification')}
    <div class="ds-wrap"><table class="ds-wind"><thead><tr><th>Winding</th><th>Start Pin</th><th>To Pin</th><th>Turns</th><th>Wire (mm)</th><th>Strand</th><th>Layer</th><th>Direction</th><th>Insulation</th></tr></thead><tbody>${windingsTableRows(data.engineering)}</tbody></table></div>
    ${sectionTitle(4, 'Transformer Diagrams')}
    <div class="ds-diagrams">
      <article class="ds-diagram"><h3>Figure 1 — Window Fill</h3><div class="ds-fig">${data.fillSvg || '<p class="ds-none">Diagram unavailable.</p>'}</div><div class="ds-legend">${(data.engineering?.rows || []).map((row, index) => `<span><i style="background:${escA(row.color)}"></i>N${index + 1} ${escA(row.name)} · ${enNum(row.turns, 0)}T · ${enNum(row.calculated_layers, 0)}L</span>`).join('')}<span class="gold"><i></i>Insulation strip between windings/layers</span></div><p class="ds-cap">Each colored band is one winding (band height ∝ build). Gold strips are the mylar tape layers; the labeled BW/HW edges are the bobbin window size.</p></article>
      <article class="ds-diagram"><h3>Figure 2 — Top View · Pinout &amp; Windings</h3><div class="ds-fig">${data.pinSvg || '<p class="ds-none">Diagram unavailable.</p>'}</div><p class="ds-cap">Coil sides on the bobbin with pin numbers per side; CW/CCW shows the winding direction of each winding.</p></article>
    </div>
    ${optionalSections(data.testData)}
    ${sectionTitle(6, 'Order Summary')}
    ${orderSummary(data.engineering, data.publicResult, data.quantity)}
    ${footer(docCode.doc, 1, 1)}
  </section>`;
  }
  window.AryReportBuildTransformer = (data) => `<!doctype html><html lang="en" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escA((data.code || 'report') + ' — datasheet')}</title><style>${reportCss}</style></head><body>${datasheetPage(data)}</body></html>`;

  /* ---------- board one-sheet (Persian, single page) ---------- */
  function boardPage(data) {
    const r = data.result || {};
    const sale = r.sale || {};
    const createdAt = new Date();
    const lineRows = (r.lines || []).map((line) => `<tr><td>${escA(line.label)}</td><td>${irr(line.amount_rial)}</td></tr>`).join('');
    const info = infoTableFa([
      ['شناسه سند', escA(data.code || '—')],
      ['عنوان پروژه', escA(data.projectTitle || '—')],
      ['مشتری', escA(data.customerName || '—')],
      ['تاریخ', escA(new Intl.DateTimeFormat('fa-IR').format(createdAt))],
      ['تعداد', `${faNum(sale.quantity, 0)} عدد`],
      ['ابعاد برد', `${faNum(data.model?.width_mm, 0)} × ${faNum(data.model?.height_mm, 0)} mm (${faNum(r.area_cm2, 1)} cm²)`],
      ['توان', `${faNum(data.model?.power_w, 0)} وات`],
      ['پیچیدگی', escA({ basic: 'ساده', medium: 'متوسط', advanced: 'پیشرفته' }[data.model?.complexity] || '—')],
    ]);
    return `<section class="page br-page">
    ${reportHeader('گزارش برآورد طراحی برد', 'Board Design Estimate', data.code || 'PREVIEW')}
    ${sectionTitle(1, 'مشخصات سفارش')}
    ${info}
    ${sectionTitle(2, 'ریز برآورد طراحی', 'مبنای قیمت: نسخه فعال فرمول برد سرور آریامن')}
    <div class="ds-wrap"><table class="br-lines"><thead><tr><th>شرح</th><th>مبلغ برآورد</th></tr></thead><tbody>${lineRows}<tr class="total"><td>جمع بهای برآورد</td><td>${irr(r.total_rial)}</td></tr></tbody></table></div>
    ${sectionTitle(3, 'قیمت فروش')}
    <div class="br-total"><div class="cell"><small>قیمت هر عدد</small><b>${irr(sale.unit_sale_rial)}</b></div><div class="cell"><small>سود اعمالی</small><b>${faNum(sale.profit_percent, 0)}٪</b></div><div class="cell"><small>مبلغ کل سفارش (${faNum(sale.quantity, 0)} عدد)</small><b>${irr(sale.total_sale_rial)}</b></div></div>
    <div class="br-note">این برآورد بر اساس مشخصات اعلامی و نسخهٔ فعال فرمول قیمت‌گذاری برد آریامن محاسبه شده است؛ قیمت نهایی پس از بازبینی مهندسی و تأیید سفارش در سامانه آریامن اعلام می‌شود. اعتبار برآورد ۷ روز است.</div>
    ${footer(data.code || 'PREVIEW', 1, 1)}
  </section>`;
  }
  function infoTableFa(rows) {
    return `<div class="ds-wrap"><table class="ds-info" style="direction:rtl"><thead><tr><th>عنوان</th><th>مقدار</th></tr></thead><tbody>${rows.map(([k, v]) => `<tr><td class="k">${k}</td><td class="v">${v}</td></tr>`).join('')}</tbody></table></div>`;
  }
  window.AryReportBuildBoard = (data) => `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escA((data.code || 'report') + ' — برآورد برد')}</title><style>${reportCss}</style></head><body>${boardPage(data)}</body></html>`;

  /* ---------- preview/print flow (no auto-print) ---------- */
  window.AryReportOpen = (html, label) => {
    const toolbar = `<div class="ary-print-bar"><button type="button" class="ary-print-btn" onclick="window.print()">چاپ / ذخیره PDF</button><span>پیش‌نمایش ${escA(label)}</span></div>`;
    const css = `<style>.ary-print-bar{position:sticky;top:0;z-index:50;display:flex;align-items:center;justify-content:center;gap:12px;background:#eef1f4;padding:10px 14px;border-bottom:1px solid #d7dee8}.ary-print-btn{background:#10243d;color:#fff;border:0;border-radius:10px;padding:9px 18px;font:inherit;font-weight:900;cursor:pointer;box-shadow:0 8px 22px rgba(16,36,61,.2)}.ary-print-btn:hover{background:#1b3a5e}.ary-print-bar span{font-size:12px;font-weight:800;color:#52626f}@media print{.ary-print-bar{display:none!important}}</style>`;
    const finalHtml = html.replace('</head>', css + '</head>').replace('<body>', '<body>' + toolbar);
    const blob = new Blob([finalHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    window.setTimeout(() => URL.revokeObjectURL(url), 120000);
  };
})();
